"""Comprehensive library of zero-parameter ARC solvers for parameter golf."""

from __future__ import annotations

try:
    import torch
    from torch import nn
    import torch.nn.functional as F
except Exception:
    torch = None
    nn = None
    F = None

from .constants import GRID_SIZE
from .grid_codec import encode_grid_to_tensor


class IdentitySolver(nn.Module):
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x


class RotationSolver(nn.Module):
    def __init__(self, k: int = 1) -> None:
        super().__init__()
        self.k = k

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return torch.rot90(x, k=self.k, dims=(2, 3))


class FlipSolver(nn.Module):
    def __init__(self, horizontal: bool = True) -> None:
        super().__init__()
        self.dims = (2,) if horizontal else (3,)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return torch.flip(x, dims=self.dims)


class TransposeSolver(nn.Module):
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x.transpose(2, 3)


class ShiftSolver(nn.Module):
    def __init__(self, dx: int, dy: int) -> None:
        super().__init__()
        self.dx = dx
        self.dy = dy

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # ARC shifts treat out-of-bounds pixels as clear, not wrapped.
        shifted = x

        if self.dy > 0:
            shifted = F.pad(shifted[:, :, : -self.dy, :], (0, 0, self.dy, 0))
        elif self.dy < 0:
            up = -self.dy
            shifted = F.pad(shifted[:, :, up:, :], (0, 0, 0, up))

        if self.dx > 0:
            shifted = F.pad(shifted[:, :, :, : -self.dx], (self.dx, 0, 0, 0))
        elif self.dx < 0:
            left = -self.dx
            shifted = F.pad(shifted[:, :, :, left:], (0, left, 0, 0))

        return shifted


class GeneralColorRemapSolver(nn.Module):
    """Input->output color remap, represented as channel permutation."""

    def __init__(self, input_to_output: list[int]) -> None:
        super().__init__()
        if len(input_to_output) != 10:
            raise ValueError("Expected 10-channel color map.")

        output_to_input = list(range(10))
        for in_color, out_color in enumerate(input_to_output):
            output_to_input[out_color] = in_color
        self.perm = output_to_input

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x[:, self.perm, :, :]


class SubgridSolver(nn.Module):
    def __init__(self, y1: int, y2: int, x1: int, x2: int) -> None:
        super().__init__()
        self.bounds = (y1, y2, x1, x2)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        sub = x[:, :, self.bounds[0] : self.bounds[1], self.bounds[2] : self.bounds[3]]
        h, w = sub.shape[2], sub.shape[3]
        return F.pad(sub, (0, GRID_SIZE - w, 0, GRID_SIZE - h))


class TilingSolver(nn.Module):
    """Repeats only the active (uh, uw) portion of the input."""

    def __init__(self, uh: int, uw: int, repeats_h: int, repeats_w: int) -> None:
        super().__init__()
        self.uh = uh
        self.uw = uw
        self.repeats = (repeats_h, repeats_w)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x is [1, 10, GRID_SIZE, GRID_SIZE]
        # Extract the unit
        unit = x[:, :, : self.uh, : self.uw]
        # Repeat it
        out = unit.repeat(1, 1, self.repeats[0], self.repeats[1])
        # Pad back to GRID_SIZE
        h, w = out.shape[2], out.shape[3]
        return F.pad(out, (0, GRID_SIZE - w, 0, GRID_SIZE - h))


class NearestNeighborScaleSolver(nn.Module):
    """Upscales the active top-left input region by integer factors."""

    def __init__(self, in_h: int, in_w: int, scale_h: int, scale_w: int) -> None:
        super().__init__()
        self.in_h = in_h
        self.in_w = in_w
        self.scale_h = scale_h
        self.scale_w = scale_w

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        unit = x[:, :, : self.in_h, : self.in_w]
        out = unit.repeat_interleave(self.scale_h, dim=2).repeat_interleave(
            self.scale_w, dim=3
        )
        h, w = out.shape[2], out.shape[3]
        return F.pad(out, (0, GRID_SIZE - w, 0, GRID_SIZE - h))


class KroneckerSolver(nn.Module):
    """
    Implements recursive ARC Kronecker product.
    Typically: Out = Kron(Unit, Unit) where Unit is a 3x3 subgrid of the input.
    """

    def __init__(self, uh: int = 3, uw: int = 3) -> None:
        super().__init__()
        self.uh = uh
        self.uw = uw

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Extract the unit (template and kernel) from the top-left
        unit = x[:, :, : self.uh, : self.uw]

        # Binary mask from unit (1 where any color is present)
        mask = torch.sum(unit[:, 1:, :, :], dim=1, keepdim=True).clamp(0, 1)

        # Recursive Kronecker: Expand mask using unit
        # [1, 1, h, w] x [1, 10, h, w] -> [1, 10, h*h, w*w]
        # We use a nested loop or reshape trick for ONNX compatibility
        batch, channels, h, w = unit.shape
        # [1, 1, h, 1, w, 1] * [1, 10, 1, h, 1, w] -> [1, 10, h, h, w, w]
        out = mask.unsqueeze(3).unsqueeze(5) * unit.unsqueeze(2).unsqueeze(4)
        out = out.reshape(batch, channels, h * h, w * w)

        # Pad back to GRID_SIZE
        h2, w2 = out.shape[2], out.shape[3]
        return F.pad(out, (0, GRID_SIZE - w2, 0, GRID_SIZE - h2))


class ConstantGridSolver(nn.Module):
    """Always emits the same grid regardless of input."""

    def __init__(self, grid: list[list[int]]) -> None:
        super().__init__()
        template = torch.from_numpy(encode_grid_to_tensor(grid))
        self.register_buffer("template", template)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.shape[0] == 1:
            return self.template
        return self.template.expand(x.shape[0], -1, -1, -1)


class ColorNormalizedSolver(nn.Module):
    """
    Wraps a backbone to make it color-invariant.
    Performs normalization and de-normalization using a task-specific map.
    """

    def __init__(self, backbone: nn.Module, color_map: list[int]) -> None:
        super().__init__()
        self.backbone = backbone
        # color_map[old] = new.
        # For channel indexing, normalization needs read_perm[new] = old.
        inv_map = [0] * 10
        for old, new in enumerate(color_map):
            inv_map[new] = old

        self.norm_perm = inv_map
        self.denorm_perm = color_map

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x is [1, 10, GRID_SIZE, GRID_SIZE]
        # Normalize: Permute channels
        x_norm = x[:, self.norm_perm, :, :]
        # Backbone logic
        out_norm = self.backbone(x_norm)
        # Denormalize: Permute channels back
        return out_norm[:, self.denorm_perm, :, :]


class CompositionalSolver(nn.Sequential):
    """Sequence of primitives."""

    pass


class ErodeSolver(nn.Module):
    """Binary erosion via min-pool (negative max-pool)."""

    def __init__(self, kernel_size: int = 3, iterations: int = 1):
        super().__init__()
        self.kernel_size = kernel_size
        self.iterations = iterations

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for _ in range(self.iterations):
            x = -F.max_pool2d(-x, self.kernel_size, stride=1, padding=self.kernel_size // 2)
        return x


class DilateSolver(nn.Module):
    """Binary dilation via max-pool."""

    def __init__(self, kernel_size: int = 3, iterations: int = 1):
        super().__init__()
        self.kernel_size = kernel_size
        self.iterations = iterations

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for _ in range(self.iterations):
            x = F.max_pool2d(x, self.kernel_size, stride=1, padding=self.kernel_size // 2)
        return x


class ProjectSolver(nn.Module):
    """Projects colors in a straight line until blocked by another color."""

    def __init__(self, direction: str):
        super().__init__()
        self.direction = direction

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = x.clone()
        for _ in range(GRID_SIZE):
            if self.direction == "right":
                shifted = F.pad(out[:, :, :, :-1], (1, 0, 0, 0))
            elif self.direction == "left":
                shifted = F.pad(out[:, :, :, 1:], (0, 1, 0, 0))
            elif self.direction == "down":
                shifted = F.pad(out[:, :, :-1, :], (0, 0, 1, 0))
            elif self.direction == "up":
                shifted = F.pad(out[:, :, 1:, :], (0, 0, 0, 1))
            else:
                shifted = out

            # Only background cells can be overwritten
            bg_mask = (out[:, 0:1, :, :] > 0.5).float()
            
            # The colors flowing in
            fill_colors = shifted[:, 1:, :, ]
            has_color = (fill_colors.sum(dim=1, keepdim=True) > 0.5).float()
            
            # Only update if the cell was bg AND there's a color flowing into it
            update_mask = bg_mask * has_color
            
            out_bg = torch.where(update_mask > 0.5, torch.zeros_like(out[:, 0:1]), out[:, 0:1])
            out_colors = torch.where(update_mask.expand(-1, 9, -1, -1) > 0.5, fill_colors, out[:, 1:])
            out = torch.cat([out_bg, out_colors], dim=1)

        return out


class AdjacencyMaskSolver(nn.Module):
    """Returns the outer 1-pixel boundary of objects (newly adjacent pixels)."""
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        d = F.max_pool2d(x, 3, stride=1, padding=1)
        # New pixels are where dilated has color but original didn't
        adj_c = torch.clamp(d[:, 1:] - x[:, 1:], 0.0, 1.0)
        # Reconstruct background (whatever is not adjacent is background)
        out_bg = 1.0 - adj_c.sum(dim=1, keepdim=True).clamp(0.0, 1.0)
        return torch.cat([out_bg, adj_c], dim=1)


class BorderMaskSolver(nn.Module):
    """Returns only the internal 1-pixel boundary of existing objects."""

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        e = -F.max_pool2d(-x, 3, stride=1, padding=1)
        # Border is original minus eroded
        border_c = torch.clamp(x[:, 1:] - e[:, 1:], 0.0, 1.0)
        # Reconstruct background
        out_bg = 1.0 - border_c.sum(dim=1, keepdim=True).clamp(0.0, 1.0)
        return torch.cat([out_bg, border_c], dim=1)



class ColorQuantizeSolver(nn.Module):
    """Reduce color palette via color remap."""

    def __init__(self, target_palette_size: int = 4):
        super().__init__()
        self.target_palette_size = target_palette_size

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch, channels, h, w = x.shape
        x_flat = x.view(batch, channels, -1)
        x_max = x_flat.max(dim=2, keepdim=True)[0]
        x_quantized = (x_flat / (x_max + 1e-8) * (self.target_palette_size - 1)).round()
        return x_quantized.view(batch, channels, h, w)


class PatternRepeatSolver(nn.Module):
    """Tile/mirror a pattern."""

    def __init__(self, tile_h: int = 2, tile_w: int = 2, mode: str = "tile"):
        super().__init__()
        self.tile_h = tile_h
        self.tile_w = tile_w
        self.mode = mode  # "tile" or "mirror"

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.mode == "mirror":
            x = torch.cat([x, torch.flip(x, dims=[-1])], dim=-1)
            x = torch.cat([x, torch.flip(x, dims=[-2])], dim=-2)
        else:
            x = x.repeat(1, 1, self.tile_h, self.tile_w)
        return x


# ─────────────────────────────────────────────────────────────────────────────
# New fundamental solver types (ONNX-safe, no Loop/Scan/NonZero/dynamic shapes)
# ─────────────────────────────────────────────────────────────────────────────


class FoldOverlaySolver(nn.Module):
    """Fold the active grid region onto itself and merge.

    Handles variable grid sizes dynamically via a baked (grid_h, grid_w),
    which is the MAXIMUM expected size across all task pairs. The flip is
    applied to the [0:grid_h, 0:grid_w] subgrid and embedded back.

    Different task pairs may have different sizes — we bake the per-task
    max so the ONNX graph is static.

    mode='or_overlay'  : flipped non-bg fills bg cells in original.
    mode='replace_bg'  : flipped value replaces wherever original is bg.
    flip_dim=2 → flip vertical (flipud), flip_dim=3 → flip horizontal (fliplr).
    """

    def __init__(self, flip_dim: int, mode: str, bg_color: int = 0,
                 grid_h: int = GRID_SIZE, grid_w: int = GRID_SIZE) -> None:
        super().__init__()
        if flip_dim not in (2, 3):
            raise ValueError("flip_dim must be 2 (H) or 3 (W)")
        if mode not in ("or_overlay", "replace_bg"):
            raise ValueError("mode must be 'or_overlay' or 'replace_bg'")
        self.flip_dim = flip_dim
        self.mode = mode
        self.bg_color = bg_color
        self.grid_h = grid_h
        self.grid_w = grid_w

        # Build row & col "alive" vectors: 1 for indices within the grid, 0 outside
        # These are static masks for ONNX
        r_mask = torch.zeros(1, 1, GRID_SIZE, 1)
        r_mask[:, :, :grid_h, :] = 1.0
        self.register_buffer("row_alive", r_mask)   # [1,1,GRID_SIZE,1]

        c_mask = torch.zeros(1, 1, 1, GRID_SIZE)
        c_mask[:, :, :, :grid_w] = 1.0
        self.register_buffer("col_alive", c_mask)   # [1,1,1,GRID_SIZE]

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Build static active mask [1, 1, GRID_SIZE, GRID_SIZE] from baked row/col alive vectors
        active_mask = self.row_alive * self.col_alive  # [1, 1, GRID_SIZE, GRID_SIZE]

        # To flip only the active subgrid:
        #   1. Zero-out padding so flipping doesn't drag padding content inside
        x_active = x * active_mask                   # [1, 10, 30, 30], zeros outside

        #   2. Flip the whole tensor (active content flips within its region)
        if self.flip_dim == 2:
            # Vertical flip of active region: row i ↔ row (grid_h-1-i)
            # After flipping whole tensor: active content is at rows (GRID_SIZE-grid_h)..(GRID_SIZE-1)
            # We need to re-align it to rows 0..(grid_h-1) by rolling it up
            flipped_full = torch.flip(x_active, dims=[2])   # content at bottom
            # Roll up by (GRID_SIZE - grid_h) to bring content to row 0
            roll_amount = self.grid_h - GRID_SIZE           # negative = roll up
            flipped = torch.roll(flipped_full, shifts=roll_amount, dims=2)
        else:
            flipped_full = torch.flip(x_active, dims=[3])   # content at right
            roll_amount = self.grid_w - GRID_SIZE
            flipped = torch.roll(flipped_full, shifts=roll_amount, dims=3)

        # Zero out anything that rolled back into the padding zone
        flipped = flipped * active_mask

        bg_ch = x[:, self.bg_color : self.bg_color + 1, :, :]
        is_bg = (bg_ch > 0.5).float() * active_mask

        if self.mode == "or_overlay":
            return x + is_bg * (flipped - x * is_bg)
        else:  # replace_bg
            return x * (1.0 - is_bg) + flipped * is_bg




class DiagonalPeriodicTilingSolver(nn.Module):
    """Tile a diagonal color sequence periodically across the whole grid.

    output[r][c] = color at phase (r + c) % period derived from the input's diagonal.
    Stores (grid_h, grid_w) so it operates only within the active region.

    ONNX-safe: only ReduceSum, element-wise multiply, and buffer arithmetic.
    """

    def __init__(self, period: int,
                 grid_h: int = GRID_SIZE, grid_w: int = GRID_SIZE,
                 bg_color: int = 0) -> None:
        super().__init__()
        self.period = period
        self.grid_h = grid_h
        self.grid_w = grid_w
        self.bg_color = bg_color

        # Pre-build phase masks: phase_masks[k, 0, r, c] = 1 iff (r+c)%period == k
        # Only within the active region
        masks = torch.zeros(period, 1, GRID_SIZE, GRID_SIZE)
        for r in range(grid_h):
            for c in range(grid_w):
                masks[(r + c) % period, 0, r, c] = 1.0
        self.register_buffer("phase_masks", masks)  # [period, 1, H, W]

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [1, 10, GRID_SIZE, GRID_SIZE]
        # We only look at the non-background channels for phase color detection
        # Build x_fg: zero out the bg channel so bg cells don't pollute phase sums
        x_fg = x.clone()
        x_fg[:, self.bg_color : self.bg_color + 1, :, :] = 0.0

        output = torch.zeros_like(x)
        for k in range(self.period):
            mask_k = self.phase_masks[k : k + 1]  # [1, 1, H, W]
            # Sum non-bg channels over phase-k positions → which color is active there?
            color_sum = (x_fg * mask_k).sum(dim=(2, 3), keepdim=True)  # [1, 10, 1, 1]
            # The winning color channel will have the largest sum
            # Broadcast back to fill all phase-k positions
            output = output + color_sum * mask_k
        return output


class GravitySolver(nn.Module):
    """Simulate pixel gravity: non-background pixels fall in a fixed direction.

    Uses an unrolled bubble-sort via adjacent comparisons (ONNX-safe, no loops in graph).
    direction: 'up', 'down', 'left', 'right'
    bg_color: the color treated as empty space (pixels fall through it).
    iterations: number of bubble-sort passes; GRID_SIZE is sufficient.
    """

    def __init__(self, direction: str, bg_color: int = 0, iterations: int = 30) -> None:
        super().__init__()
        if direction not in ("up", "down", "left", "right"):
            raise ValueError(f"Unknown direction: {direction}")
        self.direction = direction
        self.bg_color = bg_color
        self.iterations = iterations

    def _swap_step(self, x: torch.Tensor, shift: int, dim: int) -> torch.Tensor:
        """One bubble-sort pass: swap adjacent channel stacks if out of order."""
        # For 'down': roll content upward in H dim (shift= -1) and check if swap improves
        # bg channel is self.bg_color; non-bg should be below bg
        bg = x[:, self.bg_color : self.bg_color + 1, :, :]

        # shifted: look at the cell in the direction of travel
        shifted_bg = torch.roll(bg, shifts=shift, dims=dim)
        # Crop the roll artefact at the border (set border to 0 so no swap there)
        if dim == 2:
            if shift == 1:
                shifted_bg[:, :, 0, :] = 0.0
            else:
                shifted_bg[:, :, -1, :] = 0.0
        else:
            if shift == 1:
                shifted_bg[:, :, :, 0] = 0.0
            else:
                shifted_bg[:, :, :, -1] = 0.0

        # swap_mask: 1 where (current cell is bg) AND (neighbour moving here is non-bg)
        swap_mask = ((bg > 0.5) & (shifted_bg < 0.5)).float()  # [1, 1, H, W]

        # Swap: exchange content at these positions with their neighbours
        # Cell that receives non-bg (swap_mask is 1): gets shifted_x
        shifted_x = torch.roll(x, shifts=shift, dims=dim)
        
        # Cell that gives non-bg (it will receive bg): that is the neighbour cell!
        # Find which cells gave their non-bg:
        reverse_swap = torch.roll(swap_mask, shifts=-shift, dims=dim)
        reverse_x = torch.roll(x, shifts=-shift, dims=dim)

        # Apply both sides of the swap
        # 1) If cell received non-bg, it gets shifted_x
        # 2) Else If cell gave non-bg, it gets reverse_x (the bg cell)
        # 3) Else keep original x
        new_x = torch.where(swap_mask > 0.5, shifted_x, 
                            torch.where(reverse_swap > 0.5, reverse_x, x))

        # Zero the edge artefact
        if dim == 2:
            if shift == 1:
                new_x[:, :, 0, :] = x[:, :, 0, :]
            else:
                new_x[:, :, -1, :] = x[:, :, -1, :]
        else:
            if shift == 1:
                new_x[:, :, :, 0] = x[:, :, :, 0]
            else:
                new_x[:, :, :, -1] = x[:, :, :, -1]

        return new_x

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Direction → (shift, dim) for bubble-sort passes.
        # Negative shift means old index i moves to new index i-1 (moves UP/LEFT).
        # Positive shift means old index i moves to new index i+1 (moves DOWN/RIGHT).
        direction_params = {
            "down":  (1,  2),
            "up":    (-1, 2),
            "right": (1,  3),
            "left":  (-1, 3),
        }
        shift, dim = direction_params[self.direction]

        out = x
        for _ in range(self.iterations):
            out = self._swap_step(out, shift, dim)
        return out


class FloodFillSolver(nn.Module):
    """Fill enclosed background regions with a fixed colour.

    Algorithm (ONNX-safe, no Loop/NonZero):
      1. Dynamically identify active region using cumsum.
      2. Spread background-connectivity FROM the active border inward using max-pool dilations.
      3. Enclosed bg = total bg - border-reachable bg.
      4. Replace enclosed bg cells with `fill_color` channel active.

    Works for tasks where a single fixed colour fills ALL enclosed holes.
    """

    def __init__(
        self,
        fill_color: int,
        bg_color: int = 0,
        iterations: int = 60,
    ) -> None:
        super().__init__()
        self.fill_color = fill_color
        self.bg_color = bg_color
        self.iterations = iterations

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        bg = x[:, self.bg_color : self.bg_color + 1, :, :]  # [1,1,30,30]

        # Dynamically detect active region: cells that sum to >0 across all channels
        # Since encode_grid_to_tensor uses one-hot colors, sum of channels = 1 for active cells and 0 for padding.
        active_mask = x.sum(dim=1, keepdim=True)  # [1,1,30,30]

        # Build dynamic border: edge rows and cols of the active region
        # An active cell is on the border if any neighbour (or itself) is non-active
        outside_active = 1.0 - active_mask
        # Pad with 1.0 (non-active) so cells touching top/left of 30x30 are correctly marked as border
        padded_outside = F.pad(outside_active, (1, 1, 1, 1), value=1.0)
        reached_outside = F.max_pool2d(padded_outside, kernel_size=3, stride=1, padding=0)
        border_mask = active_mask * (reached_outside > 0.5).float()

        # Seed: bg cells on the border of the active region
        external = bg * border_mask

        # Flood-fill through bg cells using repeated 3×3 max-pool
        for _ in range(self.iterations):
            spread = F.max_pool2d(external, kernel_size=3, stride=1, padding=1)
            external = bg * spread  # can only spread through bg

        # Enclosed bg = in active region, is bg, NOT externally reachable
        enclosed = bg * (1.0 - external) * active_mask

        # Rebuild output: ONNX-safe (no clone): reconstruct each channel
        not_enclosed = 1.0 - enclosed
        bg_out = bg * not_enclosed  # remove bg from enclosed positions
        fill_ch = x[:, self.fill_color : self.fill_color + 1, :, :]
        fill_out = fill_ch * not_enclosed + enclosed  # add fill at enclosed

        # Reconstruct full 10-channel tensor
        channels = []
        for c in range(10):
            if c == self.bg_color:
                channels.append(bg_out)
            elif c == self.fill_color:
                channels.append(fill_out)
            else:
                channels.append(x[:, c : c + 1, :, :])
        return torch.cat(channels, dim=1)


class IsolatedPixelCrossSolver(nn.Module):
    """Each pixel that is the sole non-bg occupant of its row OR column
    extends to fill that entire row AND column with its colour.

    Detection rule used during synthesis (not in forward):
      - If a non-bg pixel is isolated in its row (row count == 1): fill the row.
      - If a non-bg pixel is isolated in its column (col count == 1): fill the col.
      - A pixel may fill both if isolated on both axes simultaneously.

    ONNX-safe: only linear algebra + broadcast (no NonZero/gather on dynamic index).

    The architecture:
      For each color channel c != bg:
        row_active[c, r]  = 1  if the row r has exactly one non-bg pixel of color c
        col_active[c, c_] = 1  if the col c_ has exactly one non-bg pixel of color c
      Then: out[c, r, col] = max(original, row_active[c,r] * isolated_in_row,
                                            col_active[c,col] * isolated_in_col)
    """

    def __init__(self, bg_color: int = 0) -> None:
        super().__init__()
        self.bg_color = bg_color

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [1, 10, 30, 30]
        out = x.clone()

        for c in range(10):
            if c == self.bg_color:
                continue
            ch = x[:, c : c + 1, :, :]  # [1, 1, 30, 30]

            row_sum = ch.sum(dim=3, keepdim=True)   # [1, 1, 30, 1] — count per row
            col_sum = ch.sum(dim=2, keepdim=True)   # [1, 1, 1, 30] — count per col

            # A row is "isolated" for this colour if exactly 1 pixel present
            row_isolated = (row_sum > 0.5) * (row_sum < 1.5)  # [1,1,30,1]
            col_isolated = (col_sum > 0.5) * (col_sum < 1.5)  # [1,1,1,30]

            # Extend: any isolated row gets that channel set to 1 across full row
            row_fill = row_isolated.expand_as(ch)   # broadcast across col axis
            col_fill = col_isolated.expand_as(ch)   # broadcast across row axis

            extended = (ch + row_fill + col_fill).clamp(0.0, 1.0)

            # Only clear bg where we've filled
            filled_mask = (extended - ch).clamp(0.0, 1.0)
            out[:, self.bg_color : self.bg_color + 1, :, :] = (
                out[:, self.bg_color : self.bg_color + 1, :, :] * (1.0 - filled_mask)
            )
            out[:, c : c + 1, :, :] = extended

        return out


class AntiTransposeSolver(nn.Module):
    """Flip over anti-diagonal: transpose then flip both axes."""

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x.transpose(2, 3).flip(2).flip(3)


class PerColorShiftSolver(nn.Module):
    """Translate each color channel independently by per-color integer offsets.

    offsets: {color: (dy, dx)} where dy=row-shift (+ = down), dx=col-shift (+ = right).
    """

    def __init__(self, offsets: dict[int, tuple[int, int]]) -> None:
        super().__init__()
        # Store as list[(dy, dx)] indexed by color
        self.offsets: list[tuple[int, int]] = [offsets.get(c, (0, 0)) for c in range(10)]

    @staticmethod
    def _shift_channel(x: torch.Tensor, dy: int, dx: int) -> torch.Tensor:
        shifted = x

        if dy > 0:
            shifted = F.pad(shifted[:, :, : -dy, :], (0, 0, dy, 0))
        elif dy < 0:
            up = -dy
            shifted = F.pad(shifted[:, :, up:, :], (0, 0, 0, up))

        if dx > 0:
            shifted = F.pad(shifted[:, :, :, : -dx], (dx, 0, 0, 0))
        elif dx < 0:
            left = -dx
            shifted = F.pad(shifted[:, :, :, left:], (0, left, 0, 0))

        return shifted

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        channels: list[torch.Tensor] = []
        for color in range(10):
            dy, dx = self.offsets[color]  # (dy, dx) order
            ch = x[:, color : color + 1, :, :]
            if dy != 0 or dx != 0:
                ch = self._shift_channel(ch, dy=dy, dx=dx)
            channels.append(ch)
        return torch.cat(channels, dim=1)

class MultiCriteriaObjectSelector(nn.Module):
    """
    Selects a specific colored object channel based on size rank and spatial position.
    Criterion: rank_idx (0=largest, 1=2nd, etc.)
    Output: [1, 1, GRID_SIZE, GRID_SIZE] mask
    """
    def __init__(self, rank_idx: int = 0) -> None:
        super().__init__()
        self.rank_idx = rank_idx

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [1, 10, GRID_SIZE, GRID_SIZE]
        # Calculate sizes of each color channel (1-9)
        counts = x[:, 1:, :, :].sum(dim=(2, 3)) # [1, 9]
        
        # Determine rank via comparison matrix (no Sort/NonZero)
        # c1 > c2 matrix
        c1 = counts.unsqueeze(2) # [1, 9, 1]
        c2 = counts.unsqueeze(1) # [1, 1, 9]
        # ranks[i] = how many channels have counts > counts[i]
        ranks = (c2 > c1).float().sum(dim=2) # [1, 9]
        
        # Match target rank
        target_mask = (ranks == float(self.rank_idx)).float() # [1, 9]
        
        # Extract the channel
        # [1, 9, 1, 1] * [1, 9, H, W] -> sum over channels
        selected_content = (target_mask.unsqueeze(2).unsqueeze(3) * x[:, 1:, :, :]).sum(dim=1, keepdim=True)
        return selected_content.clamp(0, 1)


class RankPermutationSolver(nn.Module):
    """
    Reassigns colors to object channels based on their size rank.
    permutation: [9] indices. e.g. [2, 0, 1...] means largest gets color of 2nd channel, etc.
    """
    def __init__(self, permutation: list[int]) -> None:
        super().__init__()
        self.register_buffer("p", torch.tensor(permutation, dtype=torch.long))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # 1. Identify ranks
        counts = x[:, 1:, :, :].sum(dim=(2, 3)) # [1, 9]
        c1 = counts.unsqueeze(2)
        c2 = counts.unsqueeze(1)
        ranks = (c2 > c1).float().sum(dim=2).long() # [1, 9]
        
        # 2. Map channels to their new target colors
        # For each channel c, new_color = p[rank[c]]
        new_colors = torch.gather(self.p.unsqueeze(0), 1, ranks) # [1, 9]
        
        # 3. Scatter back into [1, 10, H, W]
        # Use one-hot multiplication for ONNX
        batch, _, h, w = x.shape
        # target_one_hot: [1, 9, 9] where [0, c, c'] = 1 if channel c goes to channel c'
        target_one_hot = F.one_hot(new_colors, num_classes=9).float() 
        
        # x_fg: [1, 9, H*W]
        x_fg = x[:, 1:, :, :].reshape(batch, 9, -1)
        # res_fg: [1, 9, H*W] = RowSum( one_hot[c, c'] * x[c, pixels] )
        res_fg = torch.matmul(target_one_hot.transpose(1, 2), x_fg)
        res_fg = res_fg.view(batch, 9, h, w)
        
        # Combine with bg (bg channel 0 is preserved)
        bg = (1.0 - res_fg.sum(dim=1, keepdim=True)).clamp(0, 1)
        return torch.cat([bg, res_fg], dim=1)


class BorderAwareMaskSolver(nn.Module):
    """Mask showing objects that touch the border."""
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [1, 10, GRID_SIZE, GRID_SIZE]
        fg = x[:, 1:, :, :]
        # Check edges
        top = fg[:, :, 0, :].sum(dim=2)
        bottom = fg[:, :, -1, :].sum(dim=2)
        left = fg[:, :, :, 0].sum(dim=2)
        right = fg[:, :, :, -1].sum(dim=2)
        
        touches = ((top + bottom + left + right) > 0.5).float() # [1, 9]
        mask = (touches.unsqueeze(2).unsqueeze(3) * fg).sum(dim=1, keepdim=True)
        return mask.clamp(0, 1)


class CollisionProjectSolver(nn.Module):
    """Directional projection that stops before overlapping non-zero background."""
    def __init__(self, direction: str) -> None:
        super().__init__()
        self.direction = direction

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = x.clone()
        # Original occupancy (cannot be written into)
        occupied = (x.sum(dim=1, keepdim=True) > 0.5).float()
        
        for _ in range(GRID_SIZE):
            if self.direction == "right":
                shifted = F.pad(out[:, :, :, :-1], (1, 0, 0, 0))
            elif self.direction == "left":
                shifted = F.pad(out[:, :, :, 1:], (0, 1, 0, 0))
            elif self.direction == "down":
                shifted = F.pad(out[:, :, :-1, :], (0, 0, 1, 0))
            elif self.direction == "up":
                shifted = F.pad(out[:, :, 1:, :], (0, 0, 0, 1))
            else:
                shifted = out
                
            # shifted pixels that land on non-empty space must be blocked
            # We use shifted_background_channel as the indicator
            shifted_fg = shifted[:, 1:, :, :]
            # Land mask: where shifted pixels TRY to go
            try_mask = (shifted_fg.sum(dim=1, keepdim=True) > 0.5).float()
            
            # Blocked if target cell is ALREADY occupied in the ORIGINAL input
            blocked = try_mask * occupied
            
            # For each pixel, if blocked, we don't bring the color over.
            # (In reality, for ProjectSolver, we want to stop the WHOLE line, but 
            # local blocking is a good enough primitive for composition).
            allowed_shift = shifted_fg * (1.0 - blocked)
            
            # Update background and colors
            out_colors = (out[:, 1:, :, :] + allowed_shift).clamp(0, 1)
            out_bg = (1.0 - out_colors.sum(dim=1, keepdim=True)).clamp(0, 1)
            out = torch.cat([out_bg, out_colors], dim=1)
            
        return out


class ConditionalCompositionSolver(nn.Module):
    """Branching logic: mask * A(x) + (1-mask) * B(x)."""
    def __init__(self, mask_solver: nn.Module, solver_a: nn.Module, solver_b: nn.Module) -> None:
        super().__init__()
        self.mask_solver = mask_solver
        self.solver_a = solver_a
        self.solver_b = solver_b

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        m = self.mask_solver(x) # [1, 1, H, W]
        a = self.solver_a(x)
        b = self.solver_b(x)
        return m * a + (1.0 - m) * b
